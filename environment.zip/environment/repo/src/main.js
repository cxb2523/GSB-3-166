import { LorenzSystem } from './math/Lorenz.js';
import { SceneManager } from './core/SceneManager.js';
import GUI from 'lil-gui';

const MAX_POINT_COUNT = 100000;

const params = {
  sigma: 10,
  rho: 28,
  beta: 8 / 3,
  pointCount: 50000,
  bloomStrength: 1.5
};

const container = document.getElementById('canvas-container');
const sceneManager = new SceneManager(container, MAX_POINT_COUNT);

let lorenzSystem = new LorenzSystem(params.sigma, params.rho, params.beta);

function generateAndUpdate() {
  const result = lorenzSystem.generatePoints(params.pointCount);
  sceneManager.updateGeometry(result.positions, result.colors, params.pointCount);
}

generateAndUpdate();

const gui = new GUI();
gui.domElement.style.marginTop = '10px';
gui.domElement.style.marginRight = '10px';

const mathFolder = gui.addFolder('Lorenz Parameters');

mathFolder.add(params, 'sigma', 0.1, 50, 0.1)
  .name('Sigma (σ)')
  .onChange(() => {
    lorenzSystem.sigma = params.sigma;
    generateAndUpdate();
  });

mathFolder.add(params, 'rho', 0.1, 100, 0.1)
  .name('Rho (ρ)')
  .onChange(() => {
    lorenzSystem.rho = params.rho;
    generateAndUpdate();
  });

mathFolder.add(params, 'beta', 0.1, 10, 0.01)
  .name('Beta (β)')
  .onChange(() => {
    lorenzSystem.beta = params.beta;
    generateAndUpdate();
  });

mathFolder.open();

const renderFolder = gui.addFolder('Render Settings');

renderFolder.add(params, 'pointCount', 10000, MAX_POINT_COUNT, 1000)
  .name('Point Count')
  .onChange(() => {
    generateAndUpdate();
  });

renderFolder.add(params, 'bloomStrength', 0, 3, 0.1)
  .name('Bloom Strength')
  .onChange(() => {
    sceneManager.setBloomStrength(params.bloomStrength);
  });

renderFolder.open();

window.addEventListener('beforeunload', () => {
  sceneManager.dispose();
  gui.destroy();
});
