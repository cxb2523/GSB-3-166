import { Lorenz } from './math/Lorenz.js';
import { SceneManager } from './core/SceneManager.js';
import GUI from 'lil-gui';

class LorenzApp {
  constructor() {
    this.params = {
      sigma: 10,
      rho: 28,
      beta: 8 / 3,
      pointCount: 50000,
      bloomStrength: 1.5
    };

    this.lorenz = new Lorenz(this.params.sigma, this.params.rho, this.params.beta);
    this.sceneManager = new SceneManager(document.getElementById('container'));

    this.initGUI();
    this.generate();
  }

  initGUI() {
    this.gui = new GUI({ title: '洛伦兹吸引子参数' });

    this.gui.add(this.params, 'sigma', 0, 30, 0.1).name('σ (Sigma)').onChange(() => this.onParamsChange());
    this.gui.add(this.params, 'rho', 0, 50, 0.1).name('ρ (Rho)').onChange(() => this.onParamsChange());
    this.gui.add(this.params, 'beta', 0, 10, 0.01).name('β (Beta)').onChange(() => this.onParamsChange());
    this.gui.add(this.params, 'pointCount', 10000, 100000).step(1000).name('点数量').onChange(() => this.onPointCountChange());
    this.gui.add(this.params, 'bloomStrength', 0, 3, 0.1).name('辉光强度').onChange(() => this.onBloomChange());
  }

  onParamsChange() {
    this.lorenz.sigma = this.params.sigma;
    this.lorenz.rho = this.params.rho;
    this.lorenz.beta = this.params.beta;
    this.generate();
  }

  onPointCountChange() {
    this.generate();
  }

  onBloomChange() {
    this.sceneManager.setBloomStrength(this.params.bloomStrength);
  }

  generate() {
    const pointCount = Math.floor(this.params.pointCount);
    const { positions, colors } = this.lorenz.generatePoints(pointCount);

    if (!this.sceneManager.line) {
      this.sceneManager.createLine(pointCount);
    }

    this.sceneManager.updateLine(positions, colors);
  }
}

new LorenzApp();
