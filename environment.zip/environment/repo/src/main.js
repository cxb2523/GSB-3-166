import GUI from 'lil-gui'
import Lorenz from './math/Lorenz.js'
import SceneManager from './core/SceneManager.js'

const params = {
  sigma: 10,
  rho: 28,
  beta: 8 / 3,
  pointCount: 50000,
  bloomStrength: 1.5,
  autoRotate: true
}

function init() {
  const container = document.getElementById('canvas-container')
  const statsEl = document.getElementById('stats')
  
  const sceneManager = new SceneManager(container, {
    bloomStrength: params.bloomStrength,
    initialPointCount: params.pointCount,
    maxPointCount: 100000
  })
  
  const lorenz = new Lorenz(params)
  
  const { positions, colors } = lorenz.generate()
  sceneManager.updateGeometry(positions, colors, params.pointCount)
  
  const gui = new GUI({ title: 'Controls', width: 300 })
  
  const paramsFolder = gui.addFolder('Lorenz Parameters')
  
  paramsFolder.add(params, 'sigma', 0, 20, 0.1).onChange(updateLorenz)
  paramsFolder.add(params, 'rho', 0, 50, 0.1).onChange(updateLorenz)
  paramsFolder.add(params, 'beta', 0, 10, 0.01).onChange(updateLorenz)
  
  const perfFolder = gui.addFolder('Performance')
  
  perfFolder.add(params, 'pointCount', 10000, 100000, 1000).onChange(updateLorenz)
  
  const visualFolder = gui.addFolder('Visual Effects')
  
  visualFolder.add(params, 'bloomStrength', 0, 3, 0.1).onChange((v) => {
    sceneManager.setBloomStrength(v)
  })
  
  gui.add(params, 'autoRotate').onChange((v) => {
    sceneManager.controls.autoRotate = v
  })
  
  function updateLorenz() {
    lorenz.sigma = params.sigma
    lorenz.rho = params.rho
    lorenz.beta = params.beta
    lorenz.pointCount = params.pointCount
    
    lorenz.x = 0.1
    lorenz.y = 0
    lorenz.z = 0
    
    lorenz.updateBuffers(positions, colors)
    sceneManager.updateGeometry(positions, colors, params.pointCount)
  }
  
  function updateStats() {
    const stats = sceneManager.getStats()
    statsEl.innerHTML = `
      Points: ${params.pointCount.toLocaleString()} | 
      FPS: ${Math.round(sceneManager.renderer.info.render.frameRate || 60)} |
      Draw Calls: ${stats.calls}
    `
    requestAnimationFrame(updateStats)
  }
  
  updateStats()
  
  window.sceneManager = sceneManager
  window.lorenz = lorenz
}

document.addEventListener('DOMContentLoaded', init)
