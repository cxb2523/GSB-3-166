import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';

export class SceneManager {
  constructor(container, maxPointCount = 100000) {
    this.container = container;
    this.maxPointCount = maxPointCount;
    this.currentPointCount = maxPointCount;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x000000);

    this.camera = new THREE.PerspectiveCamera(
      60,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    this.camera.position.set(0, 0, 80);

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.container.appendChild(this.renderer.domElement);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.05;

    this.composer = new EffectComposer(this.renderer);
    this.renderPass = new RenderPass(this.scene, this.camera);
    this.composer.addPass(this.renderPass);

    this.bloomPass = new UnrealBloomPass(
      new THREE.Vector2(window.innerWidth, window.innerHeight),
      1.5,
      0.4,
      0.85
    );
    this.composer.addPass(this.bloomPass);

    this.positionArray = new Float32Array(maxPointCount * 3);
    this.colorArray = new Float32Array(maxPointCount * 3);

    this.geometry = new THREE.BufferGeometry();
    this.geometry.setAttribute('position', new THREE.BufferAttribute(this.positionArray, 3));
    this.geometry.setAttribute('color', new THREE.BufferAttribute(this.colorArray, 3));
    this.geometry.setDrawRange(0, maxPointCount);

    this.material = new THREE.LineBasicMaterial({
      vertexColors: true,
      linewidth: 1
    });

    this.line = new THREE.Line(this.geometry, this.material);
    this.scene.add(this.line);

    this.handleResize = this.handleResize.bind(this);
    window.addEventListener('resize', this.handleResize);

    this.animate = this.animate.bind(this);
    this.animationId = requestAnimationFrame(this.animate);
  }

  updateGeometry(positions, colors, pointCount) {
    this.currentPointCount = pointCount;

    for (let i = 0; i < pointCount * 3; i++) {
      this.positionArray[i] = positions[i];
      this.colorArray[i] = colors[i];
    }

    this.geometry.attributes.position.needsUpdate = true;
    this.geometry.attributes.color.needsUpdate = true;
    this.geometry.setDrawRange(0, pointCount);
  }

  setBloomStrength(strength) {
    this.bloomPass.strength = strength;
  }

  handleResize() {
    const width = window.innerWidth;
    const height = window.innerHeight;

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();

    this.renderer.setSize(width, height);
    this.composer.setSize(width, height);

    this.bloomPass.resolution.set(width, height);
  }

  animate() {
    this.animationId = requestAnimationFrame(this.animate);
    this.controls.update();
    this.composer.render();
  }

  dispose() {
    window.removeEventListener('resize', this.handleResize);
    cancelAnimationFrame(this.animationId);

    this.geometry.dispose();
    this.material.dispose();
    this.renderer.dispose();

    this.container.removeChild(this.renderer.domElement);
  }
}
