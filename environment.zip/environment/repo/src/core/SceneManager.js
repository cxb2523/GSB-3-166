import * as THREE from 'three'
import { OrbitControls } from 'three/addons/controls/OrbitControls.js'
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js'
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js'
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js'

export default class SceneManager {
  constructor(container, options = {}) {
    this.container = container
    this.maxPointCount = options.maxPointCount ?? 100000
    this.currentPointCount = options.initialPointCount ?? 50000
    
    this.initScene()
    this.initCamera()
    this.initRenderer()
    this.initControls()
    this.initPostProcessing(options.bloomStrength ?? 1.5)
    this.initLorenzLine()
    
    this.bindEvents()
    this.animate()
  }

  initScene() {
    this.scene = new THREE.Scene()
    this.scene.background = new THREE.Color(0x000000)
  }

  initCamera() {
    const width = this.container.clientWidth
    const height = this.container.clientHeight
    
    this.camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000)
    this.camera.position.set(0, 0, 80)
  }

  initRenderer() {
    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance'
    })
    
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    this.renderer.setSize(this.container.clientWidth, this.container.clientHeight)
    
    this.container.appendChild(this.renderer.domElement)
  }

  initControls() {
    this.controls = new OrbitControls(this.camera, this.renderer.domElement)
    this.controls.enableDamping = true
    this.controls.dampingFactor = 0.05
    this.controls.minDistance = 20
    this.controls.maxDistance = 200
    this.controls.autoRotate = true
    this.controls.autoRotateSpeed = 0.3
  }

  initPostProcessing(bloomStrength) {
    const width = this.container.clientWidth
    const height = this.container.clientHeight
    
    this.composer = new EffectComposer(this.renderer)
    
    const renderPass = new RenderPass(this.scene, this.camera)
    this.composer.addPass(renderPass)
    
    this.bloomPass = new UnrealBloomPass(
      new THREE.Vector2(width, height),
      bloomStrength,
      0.8,
      0.1
    )
    this.composer.addPass(this.bloomPass)
  }

  initLorenzLine() {
    this.geometry = new THREE.BufferGeometry()
    
    this.positions = new Float32Array(this.maxPointCount * 3)
    this.colors = new Float32Array(this.maxPointCount * 3)
    
    this.geometry.setAttribute('position', new THREE.BufferAttribute(this.positions, 3))
    this.geometry.setAttribute('color', new THREE.BufferAttribute(this.colors, 3))
    
    this.geometry.setDrawRange(0, this.currentPointCount)
    
    this.material = new THREE.LineBasicMaterial({
      vertexColors: true,
      linewidth: 2
    })
    
    this.line = new THREE.Line(this.geometry, this.material)
    this.scene.add(this.line)
  }

  updateGeometry(positions, colors, pointCount) {
    this.currentPointCount = pointCount
    
    const positionAttr = this.geometry.getAttribute('position')
    const colorAttr = this.geometry.getAttribute('color')
    
    positionAttr.array.set(positions)
    colorAttr.array.set(colors)
    
    positionAttr.needsUpdate = true
    colorAttr.needsUpdate = true
    
    this.geometry.setDrawRange(0, pointCount)
  }

  setBloomStrength(strength) {
    this.bloomPass.strength = strength
  }

  bindEvents() {
    window.addEventListener('resize', () => this.onResize())
  }

  onResize() {
    const width = this.container.clientWidth
    const height = this.container.clientHeight
    
    this.camera.aspect = width / height
    this.camera.updateProjectionMatrix()
    
    this.renderer.setSize(width, height)
    this.composer.setSize(width, height)
    
    this.bloomPass.setSize(width, height)
  }

  animate() {
    requestAnimationFrame(() => this.animate())
    
    this.controls.update()
    this.composer.render()
  }

  getStats() {
    const memory = this.renderer.info.memory
    const render = this.renderer.info.render
    return {
      geometries: memory.geometries,
      textures: memory.textures,
      calls: render.calls,
      points: render.points,
      lines: render.lines
    }
  }
}
