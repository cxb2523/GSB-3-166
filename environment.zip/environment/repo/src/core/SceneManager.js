import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';

export class SceneManager {
  constructor(container) {
    this.container = container;
    this.line = null;
    this.geometry = null;
    this.material = null;
    this.positionArray = null;
    this.colorArray = null;

    this.init();
  }

  init() {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x000000);

    this.camera = new THREE.PerspectiveCamera(
      60,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    this.camera.position.set(50, 50, 50);

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.container.appendChild(this.renderer.domElement);

    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.05;

    this.composer = new EffectComposer(this.renderer);
    this.renderPass = new RenderPass(this.scene, this.camera);
    this.composer.addPass(this.renderPass);

    this.bloomPass = new UnrealBloomPass(
      new THREE.Vector2(window.innerWidth, window.innerHeight),
      1.5,
      0.4,
      0.85
    );
    this.bloomPass.threshold = 0;
    this.bloomPass.strength = 1.5;
    this.bloomPass.radius = 0.5;
    this.composer.addPass(this.bloomPass);

    window.addEventListener('resize', () => this.onResize());

    this.animate();
  }

  createLine(pointCount) {
    if (this.line) {
      this.scene.remove(this.line);
    }

    this.positionArray = new Float32Array(pointCount * 3);
    this.colorArray = new Float32Array(pointCount * 3);

    this.geometry = new THREE.BufferGeometry();
    this.geometry.setAttribute(
      'position',
      new THREE.BufferAttribute(this.positionArray, 3)
    );
    this.geometry.setAttribute(
      'color',
      new THREE.BufferAttribute(this.colorArray, 3)
    );

    this.material = new THREE.LineBasicMaterial({
      vertexColors: true,
      linewidth: 1
    });

    this.line = new THREE.Line(this.geometry, this.material);
    this.scene.add(this.line);
  }

  updateLine(positions, colors) {
    if (!this.geometry) return;

    const pointCount = positions.length / 3;
    const requiredLength = positions.length;

    const currentPosAttr = this.geometry.attributes.position;
    const needsResize = !currentPosAttr || currentPosAttr.array.length !== requiredLength;

    if (needsResize) {
      this.positionArray = new Float32Array(positions.length);
      this.colorArray = new Float32Array(colors.length);
      this.geometry.setAttribute(
        'position',
        new THREE.BufferAttribute(this.positionArray, 3)
      );
      this.geometry.setAttribute(
        'color',
        new THREE.BufferAttribute(this.colorArray, 3)
      );
    }

    const posAttr = this.geometry.attributes.position;
    const colAttr = this.geometry.attributes.color;

    posAttr.array.set(positions);
    colAttr.array.set(colors);

    posAttr.needsUpdate = true;
    colAttr.needsUpdate = true;
    this.geometry.setDrawRange(0, pointCount);
  }

  setBloomStrength(strength) {
    if (this.bloomPass) {
      this.bloomPass.strength = strength;
    }
  }

  onResize() {
    const width = window.innerWidth;
    const height = window.innerHeight;

    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();

    this.renderer.setSize(width, height);
    this.composer.setSize(width, height);
    this.bloomPass.resolution.set(width, height);
  }

  animate() {
    requestAnimationFrame(() => this.animate());
    this.controls.update();
    this.composer.render();
  }

  dispose() {
    window.removeEventListener('resize', this.onResize);
    this.controls.dispose();
    this.renderer.dispose();
    if (this.geometry) {
      this.geometry.dispose();
    }
    if (this.material) {
      this.material.dispose();
    }
  }
}
