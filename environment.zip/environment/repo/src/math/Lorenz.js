export class Lorenz {
  constructor(sigma = 10, rho = 28, beta = 8 / 3) {
    this.sigma = sigma;
    this.rho = rho;
    this.beta = beta;
  }

  computeDerivatives(x, y, z) {
    const dx = this.sigma * (y - x);
    const dy = x * (this.rho - z) - y;
    const dz = x * y - this.beta * z;
    return { dx, dy, dz };
  }

  rk4Step(x, y, z, dt) {
    const k1 = this.computeDerivatives(x, y, z);
    const k2 = this.computeDerivatives(
      x + k1.dx * dt * 0.5,
      y + k1.dy * dt * 0.5,
      z + k1.dz * dt * 0.5
    );
    const k3 = this.computeDerivatives(
      x + k2.dx * dt * 0.5,
      y + k2.dy * dt * 0.5,
      z + k2.dz * dt * 0.5
    );
    const k4 = this.computeDerivatives(
      x + k3.dx * dt,
      y + k3.dy * dt,
      z + k3.dz * dt
    );

    const newX = x + (k1.dx + 2 * k2.dx + 2 * k3.dx + k4.dx) * dt / 6;
    const newY = y + (k1.dy + 2 * k2.dy + 2 * k3.dy + k4.dy) * dt / 6;
    const newZ = z + (k1.dz + 2 * k2.dz + 2 * k3.dz + k4.dz) * dt / 6;

    return { x: newX, y: newY, z: newZ };
  }

  generatePoints(pointCount, dt = 0.005) {
    const positions = new Float32Array(pointCount * 3);
    const colors = new Float32Array(pointCount * 3);
    const velocities = new Float32Array(pointCount);

    let x = 0.1;
    let y = 0;
    let z = 0;

    const warmUp = Math.min(1000, Math.floor(pointCount * 0.1));
    for (let i = 0; i < warmUp; i++) {
      const next = this.rk4Step(x, y, z, dt);
      x = next.x;
      y = next.y;
      z = next.z;
    }

    for (let i = 0; i < pointCount; i++) {
      const prevX = x;
      const prevY = y;
      const prevZ = z;

      const next = this.rk4Step(x, y, z, dt);
      x = next.x;
      y = next.y;
      z = next.z;

      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;

      const dx = x - prevX;
      const dy = y - prevY;
      const dz = z - prevZ;
      const velocity = Math.sqrt(dx * dx + dy * dy + dz * dz) / dt;
      velocities[i] = velocity;
    }

    let maxVel = 0;
    let minVel = Infinity;
    for (let i = 0; i < pointCount; i++) {
      if (velocities[i] > maxVel) maxVel = velocities[i];
      if (velocities[i] < minVel) minVel = velocities[i];
    }

    const velRange = maxVel - minVel || 1;
    for (let i = 0; i < pointCount; i++) {
      const t = (velocities[i] - minVel) / velRange;
      const color = this.velocityToColor(t);
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;
    }

    return { positions, colors };
  }

  velocityToColor(t) {
    const r = Math.min(1, t * 2);
    const g = Math.max(0, Math.min(1, 1 - Math.abs(t - 0.5) * 2));
    const b = Math.max(0, 1 - t * 2);
    return { r, g, b };
  }
}
