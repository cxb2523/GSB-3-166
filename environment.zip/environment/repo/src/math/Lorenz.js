export default class Lorenz {
  constructor(options = {}) {
    this.sigma = options.sigma ?? 10
    this.rho = options.rho ?? 28
    this.beta = options.beta ?? 8 / 3
    this.dt = options.dt ?? 0.004
    this.pointCount = options.pointCount ?? 50000
    
    this.x = options.initialX ?? 0.1
    this.y = options.initialY ?? 0
    this.z = options.initialZ ?? 0
  }

  dx(x, y, z) {
    return this.sigma * (y - x)
  }

  dy(x, y, z) {
    return x * (this.rho - z) - y
  }

  dz(x, y, z) {
    return x * y - this.beta * z
  }

  rk4Step(x, y, z) {
    const dt = this.dt
    
    const k1x = this.dx(x, y, z)
    const k1y = this.dy(x, y, z)
    const k1z = this.dz(x, y, z)
    
    const k2x = this.dx(x + k1x * dt / 2, y + k1y * dt / 2, z + k1z * dt / 2)
    const k2y = this.dy(x + k1x * dt / 2, y + k1y * dt / 2, z + k1z * dt / 2)
    const k2z = this.dz(x + k1x * dt / 2, y + k1y * dt / 2, z + k1z * dt / 2)
    
    const k3x = this.dx(x + k2x * dt / 2, y + k2y * dt / 2, z + k2z * dt / 2)
    const k3y = this.dy(x + k2x * dt / 2, y + k2y * dt / 2, z + k2z * dt / 2)
    const k3z = this.dz(x + k2x * dt / 2, y + k2y * dt / 2, z + k2z * dt / 2)
    
    const k4x = this.dx(x + k3x * dt, y + k3y * dt, z + k3z * dt)
    const k4y = this.dy(x + k3x * dt, y + k3y * dt, z + k3z * dt)
    const k4z = this.dz(x + k3x * dt, y + k3y * dt, z + k3z * dt)
    
    const nx = x + (k1x + 2 * k2x + 2 * k3x + k4x) * dt / 6
    const ny = y + (k1y + 2 * k2y + 2 * k3y + k4y) * dt / 6
    const nz = z + (k1z + 2 * k2z + 2 * k3z + k4z) * dt / 6
    
    const speed = Math.sqrt(k1x * k1x + k1y * k1y + k1z * k1z)
    
    return { x: nx, y: ny, z: nz, speed }
  }

  generate() {
    const positions = new Float32Array(this.pointCount * 3)
    const colors = new Float32Array(this.pointCount * 3)
    
    let x = this.x
    let y = this.y
    let z = this.z
    
    let maxSpeed = 0
    const speeds = new Float32Array(this.pointCount)
    
    for (let i = 0; i < this.pointCount; i++) {
      const result = this.rk4Step(x, y, z)
      x = result.x
      y = result.y
      z = result.z
      
      positions[i * 3] = x
      positions[i * 3 + 1] = y
      positions[i * 3 + 2] = z
      
      speeds[i] = result.speed
      maxSpeed = Math.max(maxSpeed, result.speed)
    }
    
    for (let i = 0; i < this.pointCount; i++) {
      const t = speeds[i] / maxSpeed
      this.speedToColor(t, colors, i * 3)
    }
    
    return { positions, colors }
  }

  speedToColor(t, colors, offset) {
    const h = (0.65 - t * 0.65)
    const s = 1
    const l = 0.4 + t * 0.2
    
    const c = (1 - Math.abs(2 * l - 1)) * s
    const x = c * (1 - Math.abs((h * 6) % 2 - 1))
    const m = l - c / 2
    
    let r, g, b
    
    if (h < 1 / 6) { r = c; g = x; b = 0 }
    else if (h < 2 / 6) { r = x; g = c; b = 0 }
    else if (h < 3 / 6) { r = 0; g = c; b = x }
    else if (h < 4 / 6) { r = 0; g = x; b = c }
    else if (h < 5 / 6) { r = x; g = 0; b = c }
    else { r = c; g = 0; b = x }
    
    colors[offset] = r + m
    colors[offset + 1] = g + m
    colors[offset + 2] = b + m
  }

  updateBuffers(positions, colors) {
    let x = this.x
    let y = this.y
    let z = this.z
    
    let maxSpeed = 0
    const speeds = new Float32Array(this.pointCount)
    
    for (let i = 0; i < this.pointCount; i++) {
      const result = this.rk4Step(x, y, z)
      x = result.x
      y = result.y
      z = result.z
      
      positions[i * 3] = x
      positions[i * 3 + 1] = y
      positions[i * 3 + 2] = z
      
      speeds[i] = result.speed
      maxSpeed = Math.max(maxSpeed, result.speed)
    }
    
    for (let i = 0; i < this.pointCount; i++) {
      const t = speeds[i] / maxSpeed
      this.speedToColor(t, colors, i * 3)
    }
  }
}
