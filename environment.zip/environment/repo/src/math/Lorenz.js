export class LorenzSystem {
  constructor(sigma = 10, rho = 28, beta = 8 / 3, dt = 0.01) {
    this.sigma = sigma;
    this.rho = rho;
    this.beta = beta;
    this.dt = dt;
  }

  computeDerivatives(x, y, z) {
    const dx = this.sigma * (y - x);
    const dy = x * (this.rho - z) - y;
    const dz = x * y - this.beta * z;
    return { dx, dy, dz };
  }

  rk4Step(x, y, z) {
    const k1 = this.computeDerivatives(x, y, z);
    const k2 = this.computeDerivatives(
      x + k1.dx * this.dt * 0.5,
      y + k1.dy * this.dt * 0.5,
      z + k1.dz * this.dt * 0.5
    );
    const k3 = this.computeDerivatives(
      x + k2.dx * this.dt * 0.5,
      y + k2.dy * this.dt * 0.5,
      z + k2.dz * this.dt * 0.5
    );
    const k4 = this.computeDerivatives(
      x + k3.dx * this.dt,
      y + k3.dy * this.dt,
      z + k3.dz * this.dt
    );

    const xNew = x + (k1.dx + 2 * k2.dx + 2 * k3.dx + k4.dx) * this.dt / 6;
    const yNew = y + (k1.dy + 2 * k2.dy + 2 * k3.dy + k4.dy) * this.dt / 6;
    const zNew = z + (k1.dz + 2 * k2.dz + 2 * k3.dz + k4.dz) * this.dt / 6;

    return { x: xNew, y: yNew, z: zNew };
  }

  generatePoints(pointCount) {
    const positions = new Float32Array(pointCount * 3);
    const colors = new Float32Array(pointCount * 3);
    const velocities = new Float32Array(pointCount);

    let x = 0.1;
    let y = 0;
    let z = 0;

    const warmupSteps = 1000;
    for (let i = 0; i < warmupSteps; i++) {
      const next = this.rk4Step(x, y, z);
      x = next.x;
      y = next.y;
      z = next.z;
    }

    let minVelocity = Infinity;
    let maxVelocity = -Infinity;

    for (let i = 0; i < pointCount; i++) {
      const prevX = x;
      const prevY = y;
      const prevZ = z;

      const next = this.rk4Step(x, y, z);
      x = next.x;
      y = next.y;
      z = next.z;

      positions[i * 3] = x;
      positions[i * 3 + 1] = y;
      positions[i * 3 + 2] = z;

      const dx = x - prevX;
      const dy = y - prevY;
      const dz = z - prevZ;
      const velocity = Math.sqrt(dx * dx + dy * dy + dz * dz) / this.dt;
      velocities[i] = velocity;

      if (velocity < minVelocity) minVelocity = velocity;
      if (velocity > maxVelocity) maxVelocity = velocity;
    }

    const velocityRange = maxVelocity - minVelocity;
    for (let i = 0; i < pointCount; i++) {
      const t = velocityRange > 0 ? (velocities[i] - minVelocity) / velocityRange : 0.5;
      const color = this.velocityToColor(t);
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;
    }

    return { positions, colors, minVelocity, maxVelocity };
  }

  velocityToColor(t) {
    const r = Math.max(0, Math.min(1, t * 2));
    const g = Math.max(0, Math.min(1, 1 - Math.abs(t - 0.5) * 2));
    const b = Math.max(0, Math.min(1, (1 - t) * 2));
    return { r, g, b };
  }
}
